package com.example.mynangosia.Mpesa;

/**
 * Created by miles on 21/11/2017.
 */

public enum Mode {
    SANDBOX,
    PRODUCTION
}
