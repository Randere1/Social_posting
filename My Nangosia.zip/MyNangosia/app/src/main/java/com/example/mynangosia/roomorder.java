package com.example.mynangosia;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class roomorder extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_roomorder);
    }
}
